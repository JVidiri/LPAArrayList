package com.vidiri.library;

import java.util.ArrayList;
import java.util.Scanner;

import com.vidiri.library.objects.Item;
import com.vidiri.library.objects.Revista;

public class Main {

	ArrayList<Item> objetosDaLista = new ArrayList<>();
	
	public static void main(String[] args) {
		System.out.println("Master lista telefonica by IFBirds");
		while(true)
		ShowMenu();
		int selectedOption = GetMenuOption();
		switch (selectedOption) {
		case 1: {
			listarTelefones();
		}
		case 2: {
			cadastrarTelefone();
		}
		case 3: {
			editarTelefone();
		}
		case 4: {
			removerTelefone();
		}
		case 5: {
			procurarTelefone();
		}
		case 6: {
			break;
		}
		default:
			throw new IllegalArgumentException("Não é uma opção valida: " + selectedOption);
		}		
	}

	private static void ShowMenu() {
		System.out.println("Por favor selecione uma das opções");
		System.out.println("1 - Listar");
		System.out.println("2 - Cadastrar");
		System.out.println("3 - Editar");
		System.out.println("4 - Remover");
		System.out.println("5 - Procurar");
	}
	
	private static int GetMenuOption(){
		Scanner scanner = new Scanner(System.in);
	    return scanner.nextInt();
	}

}
