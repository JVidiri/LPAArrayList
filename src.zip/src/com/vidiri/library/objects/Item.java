package com.vidiri.library.objects;

public class Item {
	private int id;
	private String telefone;
	private String endereco;
	private String donoEndereco;	
}
